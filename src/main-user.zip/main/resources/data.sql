
-- Usuarios
INSERT INTO users (name, email, phone, department) VALUES
('Ana López', 'ana@example.com', '987654321', 'Finanzas');
